<?php

return array(
    'activities' => array(
        'home' => array(
            'type'   => 'custom_tab',
            'action' => 'yith_ywsbs_activities_tab',
            'hide_sidebar' => true
        )
    )
);